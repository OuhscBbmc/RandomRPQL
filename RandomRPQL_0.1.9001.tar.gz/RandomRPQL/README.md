# RandomRPQL
A variable selection method for generalize linear mixed-effect models
